package com.example.tasktodo

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.navigation.NavigationView

class Login : AppCompatActivity() {

    private lateinit var btnLogin: Button
    private lateinit var editTextEmail: EditText
    private lateinit var editTextPassword: EditText
    private lateinit var sharedPreferences: SharedPreferences
    private lateinit var btnSignup: TextView

    // Shared Preferences keys
    private val sharedPrefName = "TaskTrack"
    private val keyEmail = "email"
    private val keyPassword = "password"
    private val keyIsLoggedIn = "isLoggedIn"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        btnLogin = findViewById(R.id.btn_login)
        editTextEmail = findViewById(R.id.email)
        editTextPassword = findViewById(R.id.password)
        btnSignup = findViewById(R.id.btn_signup)

        sharedPreferences = getSharedPreferences(sharedPrefName, MODE_PRIVATE)

        btnSignup.setOnClickListener {
            val intent = Intent(applicationContext, SignUp::class.java)
            startActivity(intent)
        }

        // Check if user is already logged in
        val isLoggedIn = sharedPreferences.getBoolean(keyIsLoggedIn, false)
        if (isLoggedIn) {
            val intent = Intent(applicationContext, NavigationView::class.java)
            startActivity(intent)
            finish() // Finish the current activity to prevent going back
        }

        btnLogin.setOnClickListener {
            // Get user input
            val email = editTextEmail.text.toString()
            val password = editTextPassword.text.toString()

            // Retrieve stored credentials
            val storedEmail = sharedPreferences.getString(keyEmail, null)
            val storedPassword = sharedPreferences.getString(keyPassword, null)

            // Validate credentials
            if (email == storedEmail && password == storedPassword) {
                // Set login flag
                val editor = sharedPreferences.edit()
                editor.putBoolean(keyIsLoggedIn, true)
                editor.apply()

                // Navigate to NavigationView
                val login = Intent(applicationContext, NavigationView::class.java)
                startActivity(login)
                finish() // Finish the current activity
            } else {
                // Display error message
                Toast.makeText(applicationContext, "Invalid email or password", Toast.LENGTH_SHORT).show()
            }
        }
    }
}




