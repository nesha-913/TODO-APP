package com.example.tasktodo

import android.content.Context.MODE_PRIVATE
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.AppCompatButton
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.google.android.material.floatingactionbutton.FloatingActionButton

class ProfileFragment : Fragment() {

    private lateinit var textViewName: TextView
    private lateinit var textViewEmail: TextView
    private lateinit var btnEditProfile: AppCompatButton
    private lateinit var btnLogout: FloatingActionButton

    private lateinit var sharedPreferences: SharedPreferences
    private val SHARED_PREF_NAME = "TaskTrack"
    private val KEY_NAME = "name"
    private val KEY_EMAIL = "email"
    private val KEY_IS_LOGGED_IN = "isLoggedIn"

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_profile, container, false)

        textViewName = view.findViewById(R.id.name2)
        textViewEmail = view.findViewById(R.id.email)
        btnLogout = view.findViewById(R.id.btn_logout)
        btnEditProfile = view.findViewById(R.id.btn_editProfile)

        sharedPreferences = requireActivity().getSharedPreferences(SHARED_PREF_NAME, MODE_PRIVATE)

        val name = sharedPreferences.getString(KEY_NAME, null)
        val email = sharedPreferences.getString(KEY_EMAIL, null)

        textViewName.text = name ?: ""
        textViewEmail.text = email ?: ""

        btnLogout.setOnClickListener {
            showLogoutDialog()
        }

        btnEditProfile.setOnClickListener {
            showEditProfileDialog(name, email)
        }

        return view
    }

    private fun showLogoutDialog() {
        val builder = AlertDialog.Builder(requireContext(), R.style.CustomDialogTheme)
        val inflater = layoutInflater
        val dialogView = inflater.inflate(R.layout.dialog_logout, null)
        builder.setView(dialogView)

        val dialog = builder.create()

        // Get dialog components
        val buttonYes: Button = dialogView.findViewById(R.id.button_yes)
        val buttonNo: Button = dialogView.findViewById(R.id.button_no)

        buttonYes.setOnClickListener {
            // Clear only the login flag
            with(sharedPreferences.edit()) {
                putBoolean(KEY_IS_LOGGED_IN, false) // Clear login flag
                apply()
            }
            Toast.makeText(requireContext(), "Logout Successfully", Toast.LENGTH_SHORT).show()

            // Navigate to login activity
            val intent = Intent(activity, Login::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK // Clear the back stack
            startActivity(intent)
            requireActivity().finish() // Finish the current activity to prevent going back
            dialog.dismiss()
        }

        buttonNo.setOnClickListener {
            dialog.dismiss() // Dismiss the dialog
        }

        dialog.show()
        // Set the dialog width
        dialog.window?.setLayout(1000, ViewGroup.LayoutParams.WRAP_CONTENT)
    }

    private fun showEditProfileDialog(currentName: String?, currentEmail: String?) {
        val builder = AlertDialog.Builder(requireContext(), R.style.CustomDialogTheme)
        val inflater = layoutInflater
        val dialogView = inflater.inflate(R.layout.dialog_edit, null)
        builder.setView(dialogView)

        val dialog = builder.create()

        val editTextName: EditText = dialogView.findViewById(R.id.name)
        val editTextEmail: EditText = dialogView.findViewById(R.id.email)
        val buttonYes: Button = dialogView.findViewById(R.id.button_yes)
        val buttonNo: Button = dialogView.findViewById(R.id.button_no)

        editTextName.setText(currentName)
        editTextEmail.setText(currentEmail)

        buttonYes.setOnClickListener {
            val newName = editTextName.text.toString()
            val newEmail = editTextEmail.text.toString()

            with(sharedPreferences.edit()) {
                putString(KEY_NAME, newName)
                putString(KEY_EMAIL, newEmail)
                apply()
            }

            textViewName.text = newName
            textViewEmail.text = newEmail

            dialog.dismiss()
            Toast.makeText(requireContext(), "Profile Updated Successfully", Toast.LENGTH_SHORT).show()
        }

        buttonNo.setOnClickListener {
            dialog.dismiss()
        }

        dialog.show()
        // Set the dialog width
        dialog.window?.setLayout(1000, ViewGroup.LayoutParams.WRAP_CONTENT) // Adjust width as needed
    }
}
