
package com.example.tasktodo

import android.app.Dialog
import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.google.android.material.floatingactionbutton.FloatingActionButton

class HomeFragment : Fragment() {

    private lateinit var tasksLayout: LinearLayout
    private lateinit var sharedPreferences: SharedPreferences

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val rootView = inflater.inflate(R.layout.fragment_home, container, false)
        tasksLayout = rootView.findViewById(R.id.taskList)
        val addButton: FloatingActionButton = rootView.findViewById(R.id.btn_add)
        addButton.setOnClickListener { openAddTaskDialog() }

        sharedPreferences = requireActivity().getSharedPreferences("TaskTrack", Context.MODE_PRIVATE)
        loadTasksFromSharedPreferences()
        return rootView
    }

    private fun openAddTaskDialog() {
        val dialog = createDialog(R.layout.dialog_add)
        val addButton: Button = dialog.findViewById(R.id.button_add)
        val cancelButton: Button = dialog.findViewById(R.id.button_cancel)
        val taskEditText: EditText = dialog.findViewById(R.id.task)

        addButton.setOnClickListener {
            val taskText = taskEditText.text.toString().trim()
            if (taskText.isNotEmpty()) {
                addTask(taskText)
                saveTasksToSharedPreferences()
                dialog.dismiss()
                Toast.makeText(context, "Task Added Successfully", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(activity, "Please enter a task", Toast.LENGTH_SHORT).show()
            }
        }

        cancelButton.setOnClickListener { dialog.dismiss() }
        dialog.show()
    }

    private fun openDeleteDialog(taskView: View) {
        val dialog = createDialog(R.layout.dialog_delete)
        val yesButton: Button = dialog.findViewById(R.id.button_yes)
        val noButton: Button = dialog.findViewById(R.id.button_no)

        yesButton.setOnClickListener {
            tasksLayout.removeView(taskView)
            saveTasksToSharedPreferences()
            dialog.dismiss()
            Toast.makeText(context, "Task Deleted Successfully", Toast.LENGTH_SHORT).show()
        }

        noButton.setOnClickListener { dialog.dismiss() }
        dialog.show()
    }

    private fun openEditDialog(taskView: View, taskTextView: TextView) {
        val dialog = createDialog(R.layout.dialog_edit_item)
        val updateButton: Button = dialog.findViewById(R.id.button_yes)
        val cancelButton: Button = dialog.findViewById(R.id.button_no)
        val taskEditText: EditText = dialog.findViewById(R.id.task)

        taskEditText.setText(taskTextView.text.toString())

        updateButton.setOnClickListener {
            val updatedTask = taskEditText.text.toString().trim()
            taskTextView.text = updatedTask
            saveTasksToSharedPreferences()
            dialog.dismiss()
            Toast.makeText(context, "Task Edited Successfully", Toast.LENGTH_SHORT).show()
        }

        cancelButton.setOnClickListener { dialog.dismiss() }
        dialog.show()
    }

    private fun createDialog(layoutResId: Int): Dialog {
        val dialog = Dialog(requireActivity())
        dialog.setContentView(layoutResId)
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.window?.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        return dialog
    }

    private fun addTask(taskText: String) {
        val taskView = LayoutInflater.from(activity).inflate(R.layout.card, null)
        val taskTextView: TextView = taskView.findViewById(R.id.textView21)
        val deleteImageView: ImageView = taskView.findViewById(R.id.imageView3)
        val editImageView: ImageView = taskView.findViewById(R.id.imageView2)

        taskTextView.text = taskText
        deleteImageView.setOnClickListener { openDeleteDialog(taskView) }
        editImageView.setOnClickListener { openEditDialog(taskView, taskTextView) }

        val layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        layoutParams.setMargins(0, 0, 0, 40)
        taskView.layoutParams = layoutParams

        tasksLayout.addView(taskView)
    }

    private fun saveTasksToSharedPreferences() {
        val tasksStringBuilder = StringBuilder()
        for (i in 0 until tasksLayout.childCount) {
            val taskTextView = tasksLayout.getChildAt(i).findViewById<TextView>(R.id.textView21)
            val taskText = taskTextView.text.toString()
            tasksStringBuilder.append(taskText)
            if (i < tasksLayout.childCount - 1) {
                tasksStringBuilder.append(",")
            }
        }
        val tasksString = tasksStringBuilder.toString()

        val editor = sharedPreferences.edit()
        editor.putString("tasks", tasksString)
        editor.apply()
    }

    private fun loadTasksFromSharedPreferences() {
        val tasksString = sharedPreferences.getString("tasks", "")
        if (!tasksString.isNullOrEmpty()) {
            val tasksArray = tasksString.split(",")
            for (task in tasksArray) {
                addTask(task)
            }
        }
    }
}
