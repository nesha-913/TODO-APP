package com.example.tasktodo

import android.os.Bundle
import android.widget.FrameLayout
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.navigation.NavigationBarView

class NavigationView : AppCompatActivity() {

    private lateinit var frameLayout: FrameLayout
    private lateinit var bottomNavigationView: BottomNavigationView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_navigation_view)

        // initializing widgets
        frameLayout = findViewById(R.id.frameLayout)
        bottomNavigationView = findViewById(R.id.bottom_navigation)

        // setting default fragment
        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction().replace(R.id.frameLayout, HomeFragment()).commit()
        }

        // bottom navigation
        bottomNavigationView.setOnItemSelectedListener(NavigationBarView.OnItemSelectedListener { menuItem ->
            when (menuItem.itemId) {
                R.id.homeFragment -> supportFragmentManager.beginTransaction()
                    .replace(R.id.frameLayout, HomeFragment()).commit()
                R.id.profileFragment -> supportFragmentManager.beginTransaction()
                    .replace(R.id.frameLayout, ProfileFragment()).commit()
                R.id.devInfoFragment -> supportFragmentManager.beginTransaction()
                    .replace(R.id.frameLayout, DevInfoFragment()).commit()
            }
            true
        })
    }
}
